// the navBar
// select the sections
const allSections = document.querySelectorAll("section");
const navBar = document.querySelector("ul");
allSections.forEach((section) => {
  const listItem = document.createElement("li");
  const anchor = document.createElement("a");
  anchor.href = `#${section.id}`;
  anchor.classList.add("menu__link");
  // linkItem.textContent = section.id;
  // smooth scrolling
  anchor.textContent = section.dataset.nav;
  anchor.addEventListener("click", (e) => {
    // prevent defaut
    e.preventDefault();
    // to choose the place to scroll
    section.scrollIntoView({
      behavior: "smooth",
    });
  });
  listItem.appendChild(anchor);
  navBar.appendChild(listItem);
  // active form
  document.addEventListener("scroll", () => {
    const location = section.getBoundingClientRect();
    if (location.top <= 100 && location.bottom > 100) {
      section.classList.add("active");
    } else {
      section.classList.remove("active");
    }
  });
});
// ----------------------------------------------------------
// ---------------comment form-----------
// define elements
const addButton = document.querySelector(".add");
const Name = document.querySelector(".Name");
const comment = document.querySelector(".comment");
const table = document.querySelector("table");
const Email = document.querySelector(".Email");
addButton.addEventListener("click", () => {
  // for empty input
  if (Name.value === "" || comment.value === "" || Email.value === "") {
    Name.value = "";
    comment.value = "";
    Email.value = "";
    window.alert("اخبرنا رايك");
  } 
  // for invalid email
  if(!Email.value.includes('@')){
    window.alert("Invalid email address. Please include an @ character.");
    Name.value = "";
    comment.value = "";
    Email.value = "";
  }
  // the code add the name and comment and email
  else {
    const new4 = document.createElement("tr");
    const new1 = document.createElement("td");
    const new2 = document.createElement("td");
    const new3 = document.createElement("td");
    const Delete = document.createElement("button");
    // change the text content
    new1.textContent = Name.value;
    new3.textContent = comment.value;
    new2.textContent = Email.value;
    Delete.textContent = "Delete";
    Delete.classList.add("deleteButton");
    // add class name
    new1.classList.add("new1");
    new2.classList.add("new2");
    new3.classList.add("new3");
    new4.classList.add("new4");
    // entering in the table
    new4.appendChild(new1);
    new4.appendChild(new2);
    new4.appendChild(new3);
    new4.appendChild(Delete);
    table.appendChild(new4);
    // make them in defaut
    Name.value = "";
    comment.value = "";
    Email.value = "";
    // to delete it
    Delete.addEventListener("click", () => {
      new4.remove();
    });
  }
});
